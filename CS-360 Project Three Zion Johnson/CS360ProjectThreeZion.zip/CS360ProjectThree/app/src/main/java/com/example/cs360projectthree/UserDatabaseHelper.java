package com.example.cs360projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabaseHelper extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "userDatabase";
    private static final int DATABASE_VERSION = 2;

    // User table name
    private static final String TABLE_USERS = "users";

    // User Table Columns
    private static final String KEY_ID = "id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    // Goal weight table name

    private static final String TABLE_GOAL_WEIGHT = "goal_weight";

    // Goal weight table columns
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_GOAL_WEIGHT = "goal_weight";

    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_USERNAME + " TEXT,"
                + KEY_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_GOAL_WEIGHT_TABLE = "CREATE TABLE " + TABLE_GOAL_WEIGHT + "("
                + KEY_USER_ID + " INTEGER," + KEY_GOAL_WEIGHT + " REAL" + ")";
        db.execSQL(CREATE_GOAL_WEIGHT_TABLE);
    }

    // Upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);

        onCreate(db);
    }

    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, username);
        values.put(KEY_PASSWORD, password);

        long id = db.insert(TABLE_USERS, null, values);
        db.close();

        return id;
    }

    public boolean checkUser(String username, String password) {
        String selectQuery = "SELECT  * FROM " + TABLE_USERS + " WHERE "
                + KEY_USERNAME + " = " + "'" + username + "'" + " AND " + KEY_PASSWORD + " = " + "'" + password + "'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        boolean exist = (cursor.getCount() > 0);
        cursor.close();
        db.close();

        return exist;
    }

    public int getUserId(String username, String password) {
        String selectQuery = "SELECT  * FROM " + TABLE_USERS + " WHERE "
                + KEY_USERNAME + " = " + "'" + username + "'" + " AND " + KEY_PASSWORD + " = " + "'" + password + "'";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(0);
            cursor.close();
            return userId;
        }

        return -1;
    }

    public long addGoalWeight(int userId, float goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER_ID, userId);
        values.put(KEY_GOAL_WEIGHT, goalWeight);

        long id = db.insert(TABLE_GOAL_WEIGHT, null, values);
        db.close();

        return id;
    }

    public float getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_GOAL_WEIGHT, new String[]{KEY_GOAL_WEIGHT},
                KEY_USER_ID + "=?", new String[]{String.valueOf(userId)},
                null, null, null, "1");

        if (cursor != null && cursor.moveToFirst()) {
            float goalWeight = cursor.getFloat(0);
            cursor.close();
            return goalWeight;
        }

        return -1;
    }
}