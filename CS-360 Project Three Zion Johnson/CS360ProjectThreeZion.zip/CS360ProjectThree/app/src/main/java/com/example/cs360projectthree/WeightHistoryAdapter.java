package com.example.cs360projectthree;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;



public class WeightHistoryAdapter extends RecyclerView.Adapter<WeightHistoryAdapter.ViewHolder> {

    private List<WeightEntry> weightEntries;

    public WeightHistoryAdapter(List<WeightEntry> weightEntries) {
        this.weightEntries = weightEntries;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_date_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        WeightEntry weightEntry = weightEntries.get(position);
        holder.textViewWeight.setText(String.valueOf(weightEntry.getWeight()));
        holder.textViewDate.setText(weightEntry.getDate());
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewWeight;
        public TextView textViewDate;

        public ViewHolder(View view) {
            super(view);
            textViewWeight = view.findViewById(R.id.textViewWeight);
            textViewDate = view.findViewById(R.id.textViewDate);
        }
    }
}