package com.example.cs360projectthree;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class EnterWeightActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private Button buttonDatePicker;
    private Button buttonSubmit;
    private DatabaseManager databaseManager;

    private UserDatabaseHelper userDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_weight);

        editTextWeight = findViewById(R.id.editTextWeight);
        buttonDatePicker = findViewById(R.id.buttonDatePicker);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        databaseManager = new DatabaseManager(this);
        databaseManager.open();

        final Calendar calendar = Calendar.getInstance();
        final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        buttonDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(EnterWeightActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        calendar.set(Calendar.YEAR, year);
                        calendar.set(Calendar.MONTH, month);
                        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                        buttonDatePicker.setText(dateFormat.format(calendar.getTime()));
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        userDatabaseHelper = new UserDatabaseHelper(this);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");
        int userId = userDatabaseHelper.getUserId(username, password);
        final String[] goalWeightString = new String[1];
        goalWeightString[0] = String.valueOf(userDatabaseHelper.getGoalWeight(userId));

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = editTextWeight.getText().toString();
                String date = buttonDatePicker.getText().toString();
                if (!weight.isEmpty() && !date.isEmpty()) {
                    databaseManager.insertWeight(weight, date);
                    Toast.makeText(EnterWeightActivity.this, "Weight entry added", Toast.LENGTH_SHORT).show();
                    if (goalWeightString[0].equals(weight)) {
                        Toast.makeText(EnterWeightActivity.this, "Congratulations! You have reached your goal weight!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(EnterWeightActivity.this, "Keep up the good work!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EnterWeightActivity.this, "Please enter weight and select a date", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }
}