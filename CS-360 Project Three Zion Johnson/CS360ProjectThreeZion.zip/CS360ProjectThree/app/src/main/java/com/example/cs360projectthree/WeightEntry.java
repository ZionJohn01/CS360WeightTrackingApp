package com.example.cs360projectthree;

public class WeightEntry {
    private String weight;
    private String date;

    public WeightEntry(String weight, String date) {
        this.weight = weight;
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }
}