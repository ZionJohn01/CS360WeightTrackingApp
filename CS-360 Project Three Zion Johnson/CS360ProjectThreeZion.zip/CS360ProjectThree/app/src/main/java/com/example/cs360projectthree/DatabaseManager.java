package com.example.cs360projectthree;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    private UserDatabaseHelper userDatabaseHelper;

    public DatabaseManager(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void insertWeight(String weight, String date) {
        ContentValues values = new ContentValues();
        values.put("weight", weight);
        values.put("date", date);
        database.insert("weights", null, values);


    }


    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM weights", null);
        if (cursor.moveToFirst()) {
            do {
                String weight = null;
                int weightColumnIndex = cursor.getColumnIndex("weight");
                if (weightColumnIndex != -1) {
                    weight = cursor.getString(weightColumnIndex);
                }
                String date = null;
                int dateColumnIndex = cursor.getColumnIndex("date");
                if (dateColumnIndex != -1) {
                    date = cursor.getString(dateColumnIndex);
                }
                weightEntries.add(new WeightEntry(weight, date));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weightEntries;
    }


    public void clearAllWeights() {
        database.execSQL("DELETE FROM weights");
    }
}