package com.example.cs360projectthree;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WeightHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewWeightHistory;
    private WeightHistoryAdapter weightHistoryAdapter;
    private DatabaseManager databaseManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_history);

        recyclerViewWeightHistory = findViewById(R.id.recyclerView);
        recyclerViewWeightHistory.setLayoutManager(new LinearLayoutManager(this));

        databaseManager = new DatabaseManager(this);
        databaseManager.open();

        List<WeightEntry> weightEntries = databaseManager.getAllWeights();

        weightHistoryAdapter = new WeightHistoryAdapter(weightEntries);
        recyclerViewWeightHistory.setAdapter(weightHistoryAdapter);
    }

    @Override
    protected void onDestroy() {
        databaseManager.close();
        super.onDestroy();
    }
}