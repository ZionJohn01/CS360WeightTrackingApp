package com.example.cs360projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;


public class SettingsActivity extends AppCompatActivity {

    private DatabaseManager dbManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        dbManager = new DatabaseManager(this);
        dbManager.open();
    }

    public void openAppSettings(View view) {
        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(android.net.Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }
    public void clearWeights(View view) {
        dbManager.clearAllWeights();
        Toast.makeText(this, "Weights cleared", Toast.LENGTH_SHORT).show();
    }
    protected void onDestroy() {
        dbManager.close();
        super.onDestroy();
    }
}