package com.example.cs360projectthree;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EnterGoalActivity extends AppCompatActivity {

    private UserDatabaseHelper userDatabaseHelper;
    private EditText editTextGoalWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_goal);



        userDatabaseHelper = new UserDatabaseHelper(this);
        editTextGoalWeight = findViewById(R.id.editTextWeight);
        Button buttonSubmit = findViewById(R.id.buttonSubmit);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");

        int userId = userDatabaseHelper.getUserId(username, password);


        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goalWeightString = editTextGoalWeight.getText().toString();
                if (!goalWeightString.isEmpty()) {
                    float goalWeight = Float.parseFloat(goalWeightString);
                    userDatabaseHelper.addGoalWeight(userId, goalWeight);
                    Toast.makeText(EnterGoalActivity.this, "Goal weight set", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(EnterGoalActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}