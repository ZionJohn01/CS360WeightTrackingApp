package com.example.cs360projectthree;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;

import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainMenuActivity extends AppCompatActivity {

    private UserDatabaseHelper userDatabaseHelper;
    private TextView textViewGoalWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });
        userDatabaseHelper = new UserDatabaseHelper(this);
        textViewGoalWeight = findViewById(R.id.textViewGoalWeight);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");

        int userId = userDatabaseHelper.getUserId(username, password);
        float goalWeight = userDatabaseHelper.getGoalWeight(userId);
        if (goalWeight != -1) {
            textViewGoalWeight.setText(String.valueOf(goalWeight));
        } else {
            textViewGoalWeight.setText("No goal weight set");
        }

        // Find buttons
        Button buttonWeightHistory = findViewById(R.id.buttonViewWeightHistory);
        Button buttonEnterWeight = findViewById(R.id.buttonEnterWeighIn);
        Button buttonChangeGoal = findViewById(R.id.buttonChangeGoalWeight);
        ImageButton buttonSettings = findViewById(R.id.buttonSettings);

        buttonWeightHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, WeightHistoryActivity.class));
            }
        });

        buttonEnterWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, EnterWeightActivity.class));
            }
        });

        buttonChangeGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, EnterGoalActivity.class));
            }
        });

        buttonSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainMenuActivity.this, SettingsActivity.class));
            }
        });
    }
}